import React from 'react'

export default function AdminApp(){
  return (
    <div style={{padding:24}}>
      <h2>Admin Panel (Scaffold)</h2>
      <p>Use Supabase for auth and database. This panel will include dashboards and management pages.</p>
    </div>
  )
}