import React from 'react'
import Hero from './components/Hero'

export default function App(){
  return (
    <div>
      <Hero />
      <div style={{padding:20}}>
        <p>Landing page scaffold. Replace with detailed components.</p>
      </div>
    </div>
  )
}