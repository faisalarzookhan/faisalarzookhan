import React from 'react'

export default function Hero(){
  return (
    <header style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:32}}>
      <div>
        <h1>Limitless Infotech Solution</h1>
        <p>Where Innovation Meets Execution. Empowering businesses with secure, unique, and limitless technology.</p>
        <a href="/contact" style={{background:'#FF9800',color:'#0046b3',padding:'10px 16px',borderRadius:8,textDecoration:'none'}}>Get Started</a>
      </div>
      <div style={{width:360,height:220,background:'#f3f4f6',borderRadius:16,display:'flex',alignItems:'center',justifyContent:'center'}}>
        <strong>Hero Image</strong>
      </div>
    </header>
  )
}