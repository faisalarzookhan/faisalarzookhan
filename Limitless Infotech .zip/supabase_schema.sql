-- Run these in Supabase SQL editor to create tables used by the scaffold
create table if not exists testimonials (
  id uuid default gen_random_uuid() primary key,
  client_name text,
  role text,
  company text,
  rating int,
  quote text,
  status text default 'pending',
  reply text,
  created_at timestamptz default now()
);

create table if not exists visits (
  id uuid default gen_random_uuid() primary key,
  path text,
  referrer text,
  device text,
  created_at timestamptz default now()
);

create table if not exists performance_metrics (
  id uuid default gen_random_uuid() primary key,
  metric_name text,
  value float,
  meta jsonb,
  recorded_at timestamptz default now()
);