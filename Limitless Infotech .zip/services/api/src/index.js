/**
 * Simple Express API using Supabase as the database/auth backend.
 * Replace process.env.SUPABASE_URL and process.env.SUPABASE_KEY with your Supabase project values.
 */

const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(cors());
app.use(express.json());

const SUPABASE_URL = process.env.SUPABASE_URL || 'https://your-project.supabase.co';
const SUPABASE_KEY = process.env.SUPABASE_KEY || 'public-anon-key';
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// Example: create a testimonial
app.post('/testimonials', async (req, res) => {
  const { clientName, company, rating, quote } = req.body;
  const { data, error } = await supabase.from('testimonials').insert([{
    client_name: clientName,
    company,
    rating,
    quote,
    status: 'pending'
  }]);
  if (error) return res.status(500).json({ error });
  res.json(data);
});

// Example: get approved testimonials
app.get('/testimonials', async (req, res) => {
  const { data, error } = await supabase.from('testimonials').select('*').eq('status', 'approved').order('created_at', { ascending: false });
  if (error) return res.status(500).json({ error });
  res.json(data);
});

app.post('/visits', async (req, res) => {
  const { path, referrer, device } = req.body;
  await supabase.from('visits').insert([{ path, referrer, device }]);
  res.json({ ok: true });
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log('API running on port', port));